﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cam : MonoBehaviour
{
    private GameObject Parent;
    public int RotationSpeed;
    private CapsuleCollider collide;
    public float MaxDist;
    public float MinDist = 0;
    bool Collided = false;
    private Rigidbody rigid;
    private string collideTag;
    public LayerMask layerCollide;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Parent = GetComponentInParent<Transform>().parent.gameObject;
        collide = GetComponent<CapsuleCollider>();
    }

    // Update is called once per frame
    void Update()
    {
        collide.height = Vector3.Distance(this.transform.position, Parent.transform.position)-0.3f;
        collide.center = new Vector3(0,0,collide.height/2);
        Parent.transform.Rotate(0, (Input.GetAxis("Mouse X") * RotationSpeed * Time.deltaTime), 0, Space.World);
        this.transform.position -= this.transform.forward * Time.deltaTime;
        for (int i = 0; i < 10; i++)
        {
            if (Vector3.Distance(this.transform.position, Parent.transform.position) > MaxDist)
            {
                this.transform.position += this.transform.forward*Time.deltaTime;
            }
            RaycastHit hit = new RaycastHit();
            bool hitt = false;
            Vector3 dir = ((this.transform.position - Parent.transform.position).normalized);
            hitt = Physics.CapsuleCast(Parent.transform.position, this.transform.position, collide.radius,dir,out hit,collide.height,layerCollide);
            if (hitt)
            {
                Debug.Log("Hit");
                if (hit.collider.gameObject.tag == "solid")
                {
                    Debug.Log("True");
                    this.transform.position += (this.transform.forward * Time.deltaTime);
                }
            }
        }
    }
    

}
